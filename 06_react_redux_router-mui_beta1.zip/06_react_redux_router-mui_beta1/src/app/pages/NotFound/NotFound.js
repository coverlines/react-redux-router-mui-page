import React from 'react';
import Paper from 'material-ui/Paper';
import Grid from 'material-ui/Grid';
// import './NotFound.css';

function NotFound() {

  return (
    <div className='container'>
    		<Grid container>
			<Grid item xs={12} className='Grid-lv-2 vot'>
				<h1>404 Not Found</h1>
			</Grid>
			<Grid item xs={12} sm={6} className='Grid-lv-2'>
				<Paper><h2>xs=12 sm=6</h2></Paper>
			</Grid>
			<Grid item xs={12} sm={6} className='Grid-lv-2'>
				<Paper>xs=12 sm=6</Paper>
			</Grid>
			<Grid item xs={6} sm={3} className='Grid-lv-2'>
				<Paper>xs=6 sm=3</Paper>
			</Grid>
			<Grid item xs={6} sm={3} className='Grid-lv-2'>
				<Paper>xs=6 sm=3</Paper>
			</Grid>
			<Grid item xs={6} sm={3} className='Grid-lv-2'>
				<Paper><h3>xs=6 sm=3</h3></Paper>
			</Grid>
			<Grid item xs={6} sm={3} className='Grid-lv-2'>
				<Paper>xs=6 sm=3</Paper>
			</Grid>
			<Grid item xs={6} sm={4} className='Grid-lv-2'>
				<Paper>xs</Paper>
			</Grid>
			<Grid item xs={6} sm={4} className='Grid-lv-2'>
				<Paper>xs</Paper>
			</Grid>
			<Grid item xs={12} sm={4} className='Grid-lv-2'>
				<Paper>xs</Paper>
			</Grid>
			<Grid item xs={12} sm={6} className='Grid-lv-2'>
				<Paper className='Grid-lv-3'>xs=12 sm=6</Paper>
			</Grid>
			<Grid item xs={12} sm={6} className='Grid-lv-2'>
				<Paper className='Grid-lv-3'>xs=12 sm=6</Paper>
			</Grid>
			<Grid item xs={6} sm={3} className='Grid-lv-2'>
				<Paper className='Grid-lv-3'>xs=6 sm=3</Paper>
			</Grid>
			<Grid item xs={6} sm={3} className='Grid-lv-2'>
				<Paper className='Grid-lv-3'>xs=6 sm=3</Paper>
			</Grid>
			<Grid item xs={6} sm={3} className='Grid-lv-2'>
				<Paper className='Grid-lv-3'>xs=6 sm=3</Paper>
			</Grid>
			<Grid item xs={6} sm={3} className='Grid-lv-2'>
				<Paper className='Grid-lv-3'>xs=6 sm=3</Paper>
			</Grid>
			<Grid item xs={6} sm={4} className='Grid-lv-2'>
				<Paper className='Grid-lv-3'>xs</Paper>
			</Grid>
			<Grid item xs={6} sm={4} className='Grid-lv-2'>
				<Paper className='Grid-lv-3'>xs</Paper>
			</Grid>
			<Grid item xs={12} sm={4} className='Grid-lv-2'>
				<Paper className='Grid-lv-3'>xs</Paper>
			</Grid>
		</Grid>
    </div>
  );
}

export default NotFound;