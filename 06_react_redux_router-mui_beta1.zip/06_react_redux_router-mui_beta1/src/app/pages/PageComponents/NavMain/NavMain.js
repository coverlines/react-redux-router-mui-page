import React from 'react';
import { Link } from 'react-router-dom'

import AppBar from 'material-ui/AppBar';
import Button from 'material-ui/Button';

import './NavMain.css';

import logo from './imgs/logo.svg';


function NavMain() {
  return (
    <div className="AppBar_NavMain">
      <AppBar>
            <div className="NavMain">
              <div className="container">
                <ul>
                  <li><img src={logo} className="App-logo" alt="logo" /></li>
                  <li><Button><Link to="/" className="NavPoint">Home</Link></Button></li>
                  <li><Button><Link to="/about">About</Link></Button></li>
                  <li><Button><Link to="/contact">Contact</Link></Button></li>
                  <li><Button><Link to="/failed">Failed</Link></Button></li>
                  <li className="float-right"><Button><Link to="/login">Login</Link></Button></li>
                </ul>
              </div>
            </div>
      </AppBar>
    </div>
  );
}

export default (NavMain);