import React from 'react';
import Grid from 'material-ui/Grid';

import LoginForm from '../PageComponents/LoginForm/LoginForm';

function Login() {

  return (
    <div className='container'>
		<Grid container>
			<Grid item xs={12} className='Grid-lv-2'>
				<h1>LOGIN</h1>
				<LoginForm />
			</Grid>
		</Grid>
    </div>
  );
}

export default Login;