//----------------------------------------------------------------- REACT
import React from 'react'
// import { render } from 'react-dom'
//----------------------------------------------------------------- REDUX
import { createStore, applyMiddleware, combineReducers } from 'redux'
// import { connect, Provider } from 'react-redux'
import { Provider } from 'react-redux'
//----------------------------------------------------------------- REACT-ROUTER
import { Route, Switch } from 'react-router'
//----------------------------------------------------------------- REACT-REDUX-ROUTER
import { ConnectedRouter, routerReducer, routerMiddleware } from 'react-router-redux'
import createHistory from 'history/createBrowserHistory'
//----------------------------------------------------------------- CSS
// import logo from './logo.svg';
import 'typeface-roboto'
import './App.css';
import { MuiThemeProvider, createMuiTheme } from 'material-ui/styles';
//----------------------------------------------------------------- PAGES

import NavMain from './pages/PageComponents/NavMain/NavMain'

import Home from './pages/Home/Home'
import Login from './pages/Login/Login'
import About from './pages/About/About'
import Contact from './pages/Contact/Contact'
import NotFound from './pages/NotFound/NotFound'

//----------------------------------------------------------------- STORE CONNECTION
const history = createHistory()

function AppReducer(state=[2,2,2]) {
  return state
}

const store = createStore(
  combineReducers({
    AppReducer,
    routerReducer // helpful to work with location-obj
  }),
  applyMiddleware(routerMiddleware(history))
)

store.subscribe(() => {
  console.log('subscribe', store.getState())
})

// const ConnectedSwitch = connect(state => ({
//   location: state.location
// }))(Switch)
//----------------------------------------------------------------- ROUTES
const Routes = () => (
  <div>
  
    <NavMain/>

    <Switch>
      <Route exact path="/" component={Home} />
      <Route path="/about" component={About} />
      <Route path="/contact" component={Contact} />
      <Route path="/login" component={Login} />
      <Route component={NotFound} />
    </Switch>
  </div>
)
//----------------------------------------------------------------- APP WITH REDUX // NOT WORKING WITH FEW REDUCERS !!!!!
// const AppConnect = connect(state => ({
//   location: state.location,
// }))(Routes)

//----------------------------------------------------------------- M-UI

const theme = createMuiTheme();

//----------------------------------------------------------------- PROVIDER
const App = () => (
  <MuiThemeProvider theme={theme}>
    <Provider store={store}>
      <ConnectedRouter history={history}>
        <Routes />
      </ConnectedRouter>
    </Provider>
  </MuiThemeProvider>
)
//----------------------------------------------------------------- EXPORT
export default App;